package br.gov.sp.cps.coroutines

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.time.Duration.Companion.milliseconds

class MainActivity : AppCompatActivity() {

    lateinit var campo1: TextView
    lateinit var campo2: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        campo1 = findViewById(R.id.campo_atividade_1)
        campo2 = findViewById(R.id.campo_atividade_2)

        findViewById<Button>(R.id.botao_atividade_1).setOnClickListener {

            campo1.text = ""

            CoroutineScope(context = Dispatchers.IO).launch {
                executar(campo1)
            }
        }

        findViewById<Button>(R.id.botao_atividade_2).setOnClickListener {

            campo2.text = ""

            CoroutineScope(context = Dispatchers.IO).launch {
                executar(campo2)
            }
        }
    }

    suspend fun executar(campo: TextView) {

        atividadeA(campo)
        atividadeB(campo)
        atividadeC(campo)
    }

    private suspend fun atividadeA(campo: TextView) {

        delay(duration = 1000.milliseconds)

        withContext(Dispatchers.Main) {
            campo.text = "EXECUTANDO ATIVIDADE A..."
        }
    }

    private suspend fun atividadeB(campo: TextView) {

        delay(duration = 2000.milliseconds)

        withContext(Dispatchers.Main) {
            campo.text = "EXECUTANDO ATIVIDADE B..."
        }
    }

    private suspend fun atividadeC(campo: TextView) {

        delay(duration = 3000.milliseconds)

        withContext(Dispatchers.Main) {
            campo.text = "EXECUTANDO ATIVIDADE C..."
        }
    }
}